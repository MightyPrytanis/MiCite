MiCite Local

No command line is required.

1. Unzip micite-local.zip.
2. Double-click index.html.
3. Choose Run in browser.

IMPORTANT: MiCite checks citation format only. It does not validate that a cited case or source exists, verify quoted material or legal inferences, or determine whether an authority has been overruled, superseded, abrogated, vacated, distinguished, or otherwise limited. MiCite is a formatting tool, not a cite-checking or legal-research tool.

All citation-formatting review runs locally in your browser. No document text is transmitted to Cognisint, OpenAI, Vercel, or any third-party service by this local package.
